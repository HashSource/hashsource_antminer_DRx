change the passwd of root after program nand
# usage
Alace a file named "passwd.txt" which write the new password user set in the bin folder, then the new passwork makes sense after program nand finished.
And if you don't want to change the current password, please DO NOT place any file named "passwd.txt" in bin.

# how to generate the passwd.txt
use any txt edit tool like ultraedit, notepad or something alike, or you can generate it by 'echo xxx > passwd.txt', DO replace xxx with your own password.